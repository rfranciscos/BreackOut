<p align="center">
    <img src="https://github.com/filipedeschamps/doom-fire-algorithm/blob/master/playground/render-with-canvas-and-hsl-colors/demo.gif?raw=true" width="200">
</p>

# Render with canvas and using hsl color instead of color pallet array

- [Click here for the Demo page](https://filipedeschamps.github.io/doom-fire-algorithm/playground/render-with-canvas-and-hsl-colors/)

## Author

| [<img src="https://avatars0.githubusercontent.com/u/1231655?v=3&s=115"><br><sub>@felipe-pita</sub>](https://github.com/felipe-pita) |
| :---: |