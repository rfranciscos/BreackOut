# Doom Fire Algorithm
Fire effect from Doom implemented in plain JavaScript and using Canvas's drawRect to render the final effect.

- [Click here for the Demo page](https://filipedeschamps.github.io/doom-fire-algorithm/playground/render-with-canvas-draw-rect/)