# Text on fire

## How this is working?
Maybe there's a better way to do that, but this implementation just get the text from input, write the text on canvas element. After that, using the getImageData method the text is retrieved as an image which allow me to parse its colorized pixels transforming them to an array and then apply the algorithm

- [Click here for the Demo page](https://filipedeschamps.github.io/doom-fire-algorithm/playground/texts-on-fire/)
