# Doom Fire Algorithm applied in elements
Fire effect from Doom implemented in plain JavaScript and using a Table to render the final effect above HTML elements.

- [Click here for the Demo page](https://filipedeschamps.github.io/doom-fire-algorithm/playground/burning-elements/)

## Author

| [<img src="https://avatars0.githubusercontent.com/u/15789323?v=4&s=115"><br><sub>@mmoraisa</sub>](https://github.com/mmoraisa) |
| :---: |
