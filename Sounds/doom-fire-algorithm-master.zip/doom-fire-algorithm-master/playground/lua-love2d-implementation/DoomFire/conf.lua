function love.conf(t)
	t.title = "Doom Fire"
  t.author = "WesleyCSJ"
  t.version = "11.1"
	t.window.width = 400
	t.window.height = 400
end
