# Doom Fire Algorithm

Fire effect from Doom implemented in plain JavaScript and using Canvas's drawRect to render the final effect.
Also, Pagar.me's logo is on fire. For whatever reason.

- [Click here for the Demo page](https://filipedeschamps.github.io/doom-fire-algorithm/playground/pagarme-logo-on-fire/)
