# Golang

Golang version with [ebiten 2D game library](https://github.com/hajimehoshi/ebiten)
