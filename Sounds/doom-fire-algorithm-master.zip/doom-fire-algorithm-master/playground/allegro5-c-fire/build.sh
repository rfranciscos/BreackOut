gcc -Wall main.c -lallegro -lallegro_primitives -o main -g
