
# Doom-fire-Dart
### Simple verion of Doom fire using Dart

## Preview: https://vinisaab.github.io/

- [Click here for the Demo page](https://filipedeschamps.github.io/doom-fire-algorithm/playground/follow-mouse/)
- [Click here for the Video tutorial](https://www.youtube.com/watch?v=HCjDjsHPOco)

## Author

| [<img src="https://avatars0.githubusercontent.com/u/4248081?v=3&s=115"><br><sub>@filipedeschamps</sub>](https://github.com/filipedeschamps) |
| :---: |


