import React from 'react';

const DoomTr = (props) => {
    return (
        <tr>
            {props.children}
        </tr>
    );
};

export default DoomTr;