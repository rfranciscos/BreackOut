<p align="center">
  <a href="https://filipedeschamps.github.io/doom-fire-algorithm/playground/follow-mouse/">
    <img src="https://github.com/filipedeschamps/doom-fire-algorithm/blob/master/playground/follow-mouse/demo.gif?raw=true" width="600">
  </a>
</p>

# Follow mouse
Doom Fire Effect with the algorithm of a mouse follower (very simple vector based)

- [Click here for the Demo page](https://filipedeschamps.github.io/doom-fire-algorithm/playground/follow-mouse/)
- [Click here for the Video tutorial](https://www.youtube.com/watch?v=HCjDjsHPOco)

## Author

| [<img src="https://avatars0.githubusercontent.com/u/4248081?v=3&s=115"><br><sub>@filipedeschamps</sub>](https://github.com/filipedeschamps) |
| :---: |
