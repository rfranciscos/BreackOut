# Random Walker
Random Burning Walker implemented in plain JavaScript and using Canvas's drawRect to render the final effect and with some Gravity Controls.

- [Click here for the Demo page](https://filipedeschamps.github.io/doom-fire-algorithm/playground/random-walker/)


### Original implementation
- [Implementation using plain JavaScript and Canvas's `drawRect` to render](https://filipedeschamps.github.io/doom-fire-algorithm/playground/render-with-canvas-draw-rect/) ([@leocavalcante](https://github.com/leocavalcante))
